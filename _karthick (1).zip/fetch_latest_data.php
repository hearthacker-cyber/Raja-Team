<?php
// Database connection parameters
$servername = "localhost";
$dbname = "u632480160_solarhard";
$username = "u632480160_solarhard";
$password = "root@Ershith#89";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Fetch latest data from readings table
$sql = "SELECT * FROM readings ORDER BY created_at DESC LIMIT 1"; // Fetch only the latest record
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of the latest record as JSON
    $row = $result->fetch_assoc();
    echo json_encode([$row]);
} else {
    echo json_encode([]); // Return empty array if no data found
}

$conn->close();
?>
