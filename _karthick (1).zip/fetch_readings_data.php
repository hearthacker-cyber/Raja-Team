<?php
// Database connection parameters
$servername = "localhost";
$dbname = "u632480160_solarhard";
$username = "u632480160_solarhard";
$password = "root@Ershith#89";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Fetch latest data from readings table
$sql = "SELECT * FROM solar_data ORDER BY created_at DESC LIMIT 5"; // Fetch the last 5 records
$result = $conn->query($sql);

$data = array();

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
} else {
    echo "0 results";
}

$conn->close();

// Output the data as JSON
header('Content-Type: application/json');
echo json_encode($data);
?>
