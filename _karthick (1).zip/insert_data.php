<?php

$servername = "yeezycles.com"; // Change this to your MySQL server address
$username = "u632480160_animal"; // Change this to your MySQL username
$password = "Ari@1062003"; // Change this to your MySQL password
$database = "u632480160_animal"; // Change this to your MySQL database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Function to insert data into the database
function insertData($animal) {
  global $conn;

  // Prepare and bind the SQL statement
  $stmt = $conn->prepare("INSERT INTO animal_detection (animal) VALUES (?)");
  $stmt->bind_param("s", $animal);

  // List of dummy animals
  $dummy_animals = ["elephant", "tiger", "lion", "bear", "deer"];

  // Insert dummy data
  foreach ($dummy_animals as $animal) {
    $stmt->execute();
    echo "Inserted: $animal<br>";
  }

  // Close statement
  $stmt->close();
}

// Insert dummy data
insertData("dummy_animal");

// Close connection
$conn->close();

?>
