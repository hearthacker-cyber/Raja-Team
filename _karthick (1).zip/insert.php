<?php
// Database connection parameters
$servername = "localhost";
$dbname = "u632480160_solarhard";
$username = "u632480160_solarhard";
$password = "root@Ershith#89";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if form data is received
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Escape user inputs for security
  $ambient_light = $conn->real_escape_string($_POST['ambient_light']);
  $temperature = $conn->real_escape_string($_POST['temperature']);
  $voltage = $conn->real_escape_string($_POST['voltage']);
  $current = $conn->real_escape_string($_POST['current']);

  // Attempt insert query execution
  $sql = "INSERT INTO solar_data (ambient_light, temperature, voltage, current) VALUES ('$ambient_light', '$temperature', '$voltage', '$current')";
  if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

// Close connection
$conn->close();
?>
