<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Solar Panel Monitoring</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Your custom CSS -->
  <link rel="stylesheet" href="styles.css">
</head>
<body>

<style>
  body {
    background-color: #121212;
    color: #ffffff;
  }
  .card {
    background-color: #1f1f1f;
    color: #ffffff;
    border: 1px solid #343a40;
  }
  .card-header {
    background-color: #343a40;
    color: #ffffff;
  }
</style>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <a class="navbar-brand" href="#">Solar Panel Monitoring System</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container mt-5">
  <h1 class="text-center mb-4">Solar Panel Monitoring System</h1>
  
  <div class="row">
    <div class="col-lg-4">
      <div class="card">
        <div class="card-header">Solar Panel Voltage</div>
        <div class="card-body">
          <canvas id="voltageChart" width="400" height="200"></canvas>
        </div>
      </div>
    </div>
    
    <div class="col-lg-4">
      <div class="card">
        <div class="card-header">Solar Panel Current</div>
        <div class="card-body">
          <canvas id="currentChart" width="400" height="200"></canvas>
        </div>
      </div>
    </div>
    
    <div class="col-lg-4">
      <div class="card">
        <div class="card-header">Solar Panel Temperature</div>
        <div class="card-body">
          <canvas id="temperatureChart" width="400" height="200"></canvas>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card">
      <div class="card-header">Solar Panel Ambient Light</div>
      <div class="card-body">
        <canvas id="ambientLightChart" width="400" height="200"></canvas>
      </div>
    </div>
  </div>

<?php
// Database connection parameters
$servername = "localhost";
$dbname = "u632480160_solarhard";
$username = "u632480160_solarhard";
$password = "root@Ershith#89";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Fetch latest data from readings table
$sql = "SELECT * FROM solar_data ORDER BY created_at DESC LIMIT 1"; // Fetch only the latest record
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
?>

<div class="row mt-5">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header" style="background-color: #343a40; color: aqua;">Today's Generated Current</div>
            <div class="card-body" style="color: #ffffff;">
                <p>Today's Generated Current: <strong><?php echo isset($row['current']) ? $row['current'] : "N/A"; ?> kWh</strong></p>
                <p>Time Period: <strong><?php echo isset($row['start_time']) ? $row['start_time'] : "N/A"; ?> - <?php echo isset($row['end_time']) ? $row['end_time'] : "N/A"; ?></strong></p>
                <p>Average Current: <strong><?php echo isset($row['average_current']) ? $row['average_current'] : "N/A"; ?> kWh/hour</strong></p>
                <p>Peak Current: <strong><?php echo isset($row['peak_current']) ? $row['peak_current'] : "N/A"; ?> kWh at <?php echo isset($row['peak_time']) ? $row['peak_time'] : "N/A"; ?></strong></p>
            </div>
        </div>
    </div>
</div>

<?php
} else {
    echo "<div class='row mt-5'><div class='col-lg-12'><div class='card'><div class='card-body'>0 results</div></div></div></div>";
}

// Close the connection
$conn->close();
?>

<div class="row mt-5">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header" style="background-color: #343a40; color: aqua;">Today's Generated Current</div>
            <div class="card-body" style="color: #ffffff;">
<?php
// Create connection again
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection again
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Fetch latest data from readings table
$sql = "SELECT * FROM solar_data ORDER BY created_at DESC LIMIT 5"; // Fetch the last 5 records
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = array();
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Calculate total generated energy, average current, and peak current
    $totalGeneratedEnergy = 0;
    $totalCurrent = 0;
    $peakCurrent = 0;
    foreach ($data as $row) {
        if (isset($row['voltage'], $row['current'])) {
            $totalGeneratedEnergy += $row['voltage'] * $row['current']; // Multiply voltage and current to get energy
            $totalCurrent += $row['current'];
            if ($row['current'] > $peakCurrent) {
                $peakCurrent = $row['current'];
            }
        }
    }
    $averageCurrent = ($totalCurrent > 0 && count($data) > 0) ? $totalCurrent / count($data) : 0;
?>

                <p>Today's Generated Energy: <strong><?php echo $totalGeneratedEnergy; ?> kWh</strong></p>
                <p>Average Current: <strong><?php echo $averageCurrent; ?> kWh/hour</strong></p>
                <p>Peak Current: <strong><?php echo $peakCurrent; ?> kWh at 12:00 PM</strong></p>

<?php
} else {
    echo "0 results";
}

// Close the connection
$conn->close();
?>
            </div>
        </div>
    </div>
</div>


  
  <footer class="footer mt-5 text-center" style="background-color: #343a40; color: #ffffff;">
    <p>Designed and Developed by Hifi11 Technologies</p>
  </footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@3.7.0/dist/chart.min.js"></script>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Your custom JavaScript -->
<script src="scripts.js"></script>

<script>
  // Function to fetch real-time data from the server
  function fetchRealtimeData() {
      $.ajax({
          url: "fetch_readings_data.php",
          type: "GET",
          dataType: "json",
          success: function(data) {
              // Update the charts with the fetched data
              updateCharts(data);
          },
          error: function(xhr, status, error) {
              console.error("Error fetching data:", error);
          }
      });
  }

  // Function to update the charts with the fetched data
  function updateCharts(data) {
      // Extract data from the JSON response
      const voltageData = data.map(entry => entry.voltage);
      const currentData = data.map(entry => entry.current);
      const temperatureData = data.map(entry => entry.temperature);
      const ambientLightData = data.map(entry => entry.ambient_light);
      const createdAtData = data.map(entry => entry.created_at);

      // Update the charts with the new data
      updateChart('voltageChart', 'Voltage', createdAtData, voltageData);
      updateChart('currentChart', 'Current', createdAtData, currentData);
      updateChart('temperatureChart', 'Temperature', createdAtData, temperatureData);
      updateChart('ambientLightChart', 'Ambient Light', createdAtData, ambientLightData);
  }

  // Function to update a chart
  function updateChart(chartId, label, labels, data) {
      const chartCanvas = document.getElementById(chartId).getContext('2d');
      const chart = new Chart(chartCanvas, {
          type: 'line',
          data: {
              labels: labels,
              datasets: [{
                  label: label,
                  data: data,
                  borderColor: getRandomColor(), // Function to generate a random color
                  borderWidth: 1
              }]
          },
          options: {
              responsive: true,
              maintainAspectRatio: false,
          }
      });
  }

  // Call fetchRealtimeData function initially and every 5 seconds
  $(document).ready(function() {
      fetchRealtimeData();
      setInterval(fetchRealtimeData, 5000); // Update every 5 seconds
  });

  // Function to generate a random color
  function getRandomColor() {
      const letters = '0123456789ABCDEF';
      let color = '#';
      for (let i = 0; i < 6; i++) {
          color += letters[Math.floor(Math.random() * 16)];
      }
      return color;
  }
</script>

</body>
</html>
