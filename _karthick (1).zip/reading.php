<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Readings Table</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<div class="container mt-5">
    <h1 class="mb-4">Readings Table</h1>
    <table id="readingsTable" class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ambient Light</th>
                <th>Temperature</th>
                <th>Voltage</th>
                <th>Current</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <!-- Table body will be filled dynamically using Ajax -->
        </tbody>
    </table>
</div>

<!-- Bootstrap JS -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
// Function to fetch and update the readings table using Ajax
function updateReadingsTable() {
    $.ajax({
        url: "fetch_latest_data.php", // PHP script to fetch latest data
        type: "GET",
        dataType: "json",
        success: function(data) {
            // Clear existing table rows
            $("#readingsTable tbody").empty();
            // Add new rows with fetched data
            $.each(data, function(index, row) {
                $("#readingsTable tbody").append(
                    "<tr>" +
                    "<td>" + row.id + "</td>" +
                    "<td>" + row.ambient_light + "</td>" +
                    "<td>" + row.temperature + "</td>" +
                    "<td>" + row.voltage + "</td>" +
                    "<td>" + row.current + "</td>" +
                    "<td>" + row.created_at + "</td>" +
                    "</tr>"
                );
            });
        },
        error: function(xhr, status, error) {
            console.error("Error fetching data:", error);
        }
    });
}

// Update the readings table initially and every 5 seconds
$(document).ready(function() {
    updateReadingsTable();
    setInterval(updateReadingsTable, 5000); // Update every 5 seconds
});
</script>

</body>
</html>
