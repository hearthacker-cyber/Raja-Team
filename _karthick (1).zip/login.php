<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <style>
    .login-container {
      margin-top: 50px;
    }
    .footer {
      position: fixed;
      bottom: 0;
      width: 100%;
      background-color: #f8f9fa;
      text-align: center;
      padding: 10px 0;
    }
  </style>
</head>
<body>

<div class="container">
  <h2 class="text-center mt-5 mb-4">Solar Management Admin Login</h2>
  <div class="row justify-content-center login-container">
    <div class="col-md-6">
      <div class="card">
        <div class="card-header bg-primary text-white">
          <h4>Login</h4>
        </div>
        <div class="card-body">
          <form action="update_backend.php" method="POST">
            <div class="form-group">
              <label for="username">Username</label>
              <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<br><br><br><br>
<div class="footer">
  <p>Designed and Developed by Hifi11 Technologies</p>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
  $(document).ready(function() {
    $('form').submit(function(event) {
      var username = $('#username').val();
      var password = $('#password').val();
      if (username === 'admin' && password === 'admin') {
        // Allow form submission
        return true;
      } else {
        // Prevent form submission
        event.preventDefault();
        alert('Invalid username or password');
      }
    });
  });
</script>

</body>
</html>
