<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Solar Management</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <style>
    .top-bar {
      background-color: #343a40;
      color: white;
      padding: 10px 0;
    }

    .footer {
      background-color: #343a40;
      color: white;
      padding: 20px 0;
      text-align: center;
      position: fixed;
      bottom: 0;
      width: 100%;
    }
  </style>
</head>
<body>

<div class="top-bar text-center">
  <h3>Solar Management</h3>
</div>

<div class="container mt-4">
  <form action="insert.php" method="POST">
    <div class="mb-3">
      <label for="ambient_light" class="form-label">Ambient Light</label>
      <div class="input-group">
        <input type="text" class="form-control" id="ambient_light" name="ambient_light" placeholder="Enter ambient light">
        <span class="input-group-text"><i class="fas fa-sun"></i></span>
      </div>
    </div>

    <div class="mb-3">
      <label for="temperature" class="form-label">Temperature</label>
      <div class="input-group">
        <input type="text" class="form-control" id="temperature" name="temperature" placeholder="Enter temperature">
        <span class="input-group-text"><i class="fas fa-thermometer-half"></i></span>
      </div>
    </div>

    <div class="mb-3">
      <label for="voltage" class="form-label">Voltage</label>
      <div class="input-group">
        <input type="text" class="form-control" id="voltage" name="voltage" placeholder="Enter voltage">
        <span class="input-group-text"><i class="fas fa-bolt"></i></span>
      </div>
    </div>

    <div class="mb-3">
      <label for="current" class="form-label">Current</label>
      <div class="input-group">
        <input type="text" class="form-control" id="current" name="current" placeholder="Enter current">
        <span class="input-group-text"><i class="fas fa-charging-station"></i></span>
      </div>
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

<div class="footer">
  <p>Designed and Developed by HiFi11 Technologies</p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
</body>
</html>
